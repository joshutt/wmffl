<?
$title = "Schedule";
include "teamheader.php";

include "indschedule.php";

include "$DOCUMENT_ROOT/base/footer.html";
?>
