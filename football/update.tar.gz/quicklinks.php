<table width="100%">
<tr><td class="cat" colspan="2">Other Links</td></tr>
<tr><td align="left" width="*">
<p><a href="/history/2008Season/protectioncost09.php">2009 Protection Costs</a></p>
</td>

<td align="right" width="*">
<p><a href="/history/2009Season/seasonposition.php">2009 Draft Weights</a></p>
</td>
</tr>

<tr><td align="left" width="*">
<p><a href="/history/2008Season/teammoney.shtml">2008 League Payments</a></p>
</td>

<!--
<td align="right" width="*">
<p><a href="/rules/proposals2008.php">2008 Rule Change Proposals</a></p>
</td>
-->
</tr>
<!--
<tr><td>&nbsp;</td></tr>

<tr>
<td align="left" width="*">
<p><a href="/history/2008Season/draftorder.php">2008 Draft Order</a></p>
</td>

<td align="right" width="*">
<p><a href="/transactions/showprotections.php">View Protections</a></p>
</td>
</tr>

<tr><td>&nbsp;</td></tr>

<tr>
<td align="left" width="*">
<p><a href="/transactions/livedraft/index.php">Live Draft!!!!!</a></p>
</td>

<td align="right" width="*">
<p><a href="/history/2008Season/draftresults.php">Draft Results</a></p>
</td>
</tr>
-->
</table>
